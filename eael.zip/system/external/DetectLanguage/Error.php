<?php

namespace DetectLanguage;

// backwards compatibility
class DetectLanguageError extends \Exception
{
}

class Error extends DetectLanguageError
{
}
