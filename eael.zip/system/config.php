<?php
define("DB_HOST", "localhost");
define("DB_NAME", "u570232755_nmpg");
define("DB_USER", "u570232755_mpg");
define("DB_PASS", "salamander566");
?>