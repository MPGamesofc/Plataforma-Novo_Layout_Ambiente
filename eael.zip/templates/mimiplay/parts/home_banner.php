<div class="home-banner banner-ad">
    <div class="col-md-12 text-center">
     <?php echo htmlspecialchars_decode($get->system("widget_banner_top")); ?>
    </div>
</div>